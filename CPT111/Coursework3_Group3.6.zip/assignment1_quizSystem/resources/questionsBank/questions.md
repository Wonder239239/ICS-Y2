<?xml version="1.0" encoding="UTF-8"?>
<questions>
    <question>
        <questionString>Question 1</questionString>
        <option>option 1-1</option>
        <option answer>option 1-2</option>
        <option>option 1-3</option>
        <option>option 1-4</option>
    </question>
        <questionString>Question 2</questionString>
        <option>option 2-1</option>
        <option answer>option 2-2</option>
        <option>option 2-3</option>
        <option>option 2-4</option>
    </question>
        <questionString>Question 3</questionString>
        <option>option 3-1</option>
        <option answer>option 3-2</option>
        <option>option 3-3</option>
        <option>option 3-4</option>
    </question>
        <questionString>Question 4</questionString>
        <option>option 4-1</option>
        <option answer>option 4-2</option>
        <option>option 4-3</option>
        <option>option 4-4</option>
    </question>
</questions>

