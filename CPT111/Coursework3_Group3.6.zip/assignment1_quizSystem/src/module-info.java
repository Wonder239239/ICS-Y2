/**
 * CPT111 Laboratory: Complexity Analysis
 */
module xjtlu.cpt111.assignment.quiz {
	exports xjtlu.cpt111.assignment.quiz;
	requires xjtlu.cpt111.assignment.quiz.lib;
}
