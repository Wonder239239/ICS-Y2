package xjtlu.cpt111.assignment.quiz;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

//Category: used to show each topic's highest score
public class LeaderBoard extends userHighestScore {
    // The CSV file location for every theme
    private static String csScore = "resources/scores-cs.csv";
    private static String eeScore = "resources/scores-ee.csv";
    private static String englishScore = "resources/scores-english.csv";
    private static String mathematicsScore = "resources/scores-mathematics.csv";

    /**
     * From the user data in the downloaded file, choose the users with the highest ratings.
     */
    private static List<userHighestScore> HighestScoreInfo(List<userHighestScore> list) {
        List<userHighestScore> HighestScoreName = new ArrayList<>();//Save the user data with the highest score.
        if (list.isEmpty()) {
            return HighestScoreName;//If the list is empty, return an empty list
        }

        int maxValue = Integer.MIN_VALUE;//Initialize the highest score to be the smallest number

        //use an extended for loop,to search through the list and find the user with the highest score
        for (userHighestScore users : list) {
            if(users.getHighestScore() > maxValue) {
                maxValue = users.getHighestScore();//Update the  new highest score
                HighestScoreName.clear();//Clear previous records
                HighestScoreName.add(users);//Add the current highest scoring user
            } else if (users.getHighestScore() == maxValue) {
                HighestScoreName.add(users);//If the highest scores are equal, add them together
            }
            else continue;//If the score is lower than the current highest score, ignore it
        }
        return HighestScoreName;//Return to the list of the user with the highest scores
    }

    /**
     * Reads files linked to a certain subject and prints out the users with the highest scores on that subject.
     */
    private static void sort(String topic,String file){
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            List<userHighestScore> users = new ArrayList<>();//Store the user information
            String line;

            //Read user information line by line
            while ((line = reader.readLine()) != null) {
                String[] info = line.split(",");//Split characters by comma
                // Check if there is sufficient information in the line.
                if (info.length >= 3) {
                    // Create a userHighestScore object and add it to the users list
                    userHighestScore user = new userHighestScore(info[0],Integer.parseInt(info[1]));
                    users.add(user);
                }
            }
            // Get a list of the highest scoring users
            List<userHighestScore> list= HighestScoreInfo(users);
            System.out.println(topic);// Print the topic name
            System.out.println("First Place:");
            // Check if there is a user with a score to display
            if (!list.isEmpty()) {
                for (userHighestScore user : list) {
                    System.out.println(user);
                }
                System.out.println();
            }
            //if the users' list is empty
            else {
                System.out.print("Nobody has taken this topic's quiz yet.");
                System.out.println();
            }
            System.out.println();
        }
        // Address any IO exceptions that come up when the file is being read.
        catch (IOException e) {
            System.err.println("Error reading the CSV file: " + e.getMessage());
        }
    }

    /**
     * Create a ranking list and use the sort technique to sort the scores for each subject.
     */
    public static void leaderBoard() {
        sort("cs", csScore);
        sort("ee", eeScore);
        sort("english", englishScore);
        sort("mathematics", mathematicsScore);

    }
}
