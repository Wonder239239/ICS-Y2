package xjtlu.cpt111.assignment.quiz;

import java.io.IOException;
import java.util.Scanner;

public class Menu {
    //A static variable is used to store the logged-in user information.
    public static SharedUser loggedInUser= null;

    public static void main(String[] args) throws IOException {
        // Create a Scanner object to get user input
        Scanner scanner = new Scanner(System.in);
        int choice;
        // Call the userLogin method in Login
        Login.userLogin(scanner);
        // Call the user login method
        while (true) {
            // Show the menu
            show();
            System.out.print("Please enter your choice: ");
            String input = scanner.nextLine();
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Incorrect input! Please enter the correct number.");
                continue;
            }

            switch (choice) {
                case 1:
                    System.out.println("*****  Quiz taking   *****");
                    QuizTaking.takingQuiz(scanner);
                    break;
                case 2:
                    System.out.println("*****  LeaderBoard   *****");
                    LeaderBoard.leaderBoard();
                    break;
                case 3:
                    UserDashboard.printScores(scanner);
                    break;
                case 0:
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Wrong input, please put correct choice ！");
            }
        }
    }

    /**
     * Show the menu
     */
    public static void show() {
        System.out.println("***************************");
        System.out.println("0、Quit");
        System.out.println("1、Quiz taking ");
        System.out.println("2、LeaderBoard");
        System.out.println("3、User dashboard");
        System.out.println("***************************");
    }
}
