package xjtlu.cpt111.assignment.quiz;

import xjtlu.cpt111.assignment.quiz.model.Difficulty;
import xjtlu.cpt111.assignment.quiz.model.Option;
import xjtlu.cpt111.assignment.quiz.model.Question;
import xjtlu.cpt111.assignment.quiz.util.IOUtilities;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import static xjtlu.cpt111.assignment.quiz.Menu.loggedInUser;


public class QuizTaking {
    private static int num;
    private static String csvFile;
    public static String cs = "resources/questionsBank/questions_cs.xml";
    public static String ee = "resources/questionsBank/questions_ee.xml";
    public static String english = "resources/questionsBank/questions_english.xml";
    public static String mathematics = "resources/questionsBank/questions_mathematics.xml";
    private static final String csScore = "resources/scores-cs.csv";
    private static final String eeScore = "resources/scores-ee.csv";
    private static final String englishScore = "resources/scores-english.csv";
    private static final String mathematicsScore = "resources/scores-mathematics.csv";
    public static Question[] questions;

    /**
     * Read questions from the .xml file.
     */
    public static Question[] readQuestions(String filename) {
        try {
            return IOUtilities.readQuestions(filename);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    /**
     * Prompts the user to choose a topic for the quiz and sets the corresponding question file and CSV file.
     */
    public static void chooseTopic(Scanner scanner) {
        System.out.println("Choose a topic");
        int choice;
        while(true) {
            System.out.println("1. Computer Science (cs) ");
            System.out.println("2. Electrical Engineering (ee) ");
            System.out.println("3. English ");
            System.out.println("4. Mathematics ");
            System.out.println("Please enter a number to choose the topic ");
            System.out.print("Your choice: ");
            String input = scanner.nextLine();
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, please enter a number!");
                continue;
            }

            switch (choice) {
                case 1:
                    questions= readQuestions(cs);
                    csvFile = csScore;
                    break;
                case 2:
                    questions= readQuestions(ee);
                    csvFile = eeScore;
                    break;
                case 3:
                    questions= readQuestions(english);
                    csvFile = englishScore;
                    break;
                case 4:
                    questions= readQuestions(mathematics);
                    csvFile = mathematicsScore;
                    break;
                default:
                    System.out.println("Please choose the number between 1 to 4, please choose again!");
                    continue;
            }
            break;
        }

    }

    /**
     * Prompts the user to enter the number of questions for the quiz and validates the input.
     */
    public static void chooseQuestionNum(Scanner scanner) {
        while (true) {
            int maxNum = 0;
            for(Question q : questions) {
                if (q!=null) maxNum++;
            }
            System.out.print("Please enter the number of the questions(at least 4 questions,at most "+maxNum+" answers): ");
            try {
                num = Integer.parseInt(scanner.nextLine());
                if (num >= 4 && num <= maxNum) {
                    break;
                }
                if (num < 4) {
                    System.out.println("At least 4 questions, please choose again!");
                }
                if (num > maxNum) {
                    System.out.println("At most "+maxNum+" answers, please choose again!");
                }
            }
            catch (Exception e) {
                System.out.println("Invalid input, please choose again!");
            }
        }
    }

    /**
     * Selects a specified number of questions from different difficulty levels.
     * The method takes an array of all available questions and the desired number of questions to select.
     * It returns an array containing the selected questions.
     */
    public static Question[] selectQuestion(Question[] questions, int num) {
        // Classify questions into different difficulty levels.
        Question[] easyQuestions = classify(questions, Difficulty.EASY);
        Question[] mediumQuestions = classify(questions, Difficulty.MEDIUM);
        Question[] hardQuestions = classify(questions, Difficulty.HARD);
        Question[] veryHardQuestions = classify(questions, Difficulty.VERY_HARD);

        // Calculate the number of questions to select from each difficulty level.
        int numPerDifficulty = num / 4;

        // Initialize an array of question type to store the selected questions.
        Question[] selectedQuestions = new Question[num];
        int index = 0;
        int actualNum = 0;

        // Select random questions from each difficulty level.
        actualNum = Math.min(numPerDifficulty, easyQuestions.length);
        Question[] selectedEasy = selectRandomQuestions(easyQuestions, actualNum);
        System.arraycopy(selectedEasy, 0, selectedQuestions, index, actualNum);
        index += actualNum;

        actualNum = Math.min(numPerDifficulty, mediumQuestions.length);
        Question[] selectedMedium = selectRandomQuestions(mediumQuestions, actualNum);
        System.arraycopy(selectedMedium, 0, selectedQuestions, index, actualNum);
        index += actualNum;

        actualNum = Math.min(numPerDifficulty, hardQuestions.length);
        Question[] selectedHard = selectRandomQuestions(hardQuestions, actualNum);
        System.arraycopy(selectedHard, 0, selectedQuestions, index, actualNum);
        index += actualNum;

        actualNum = Math.min(numPerDifficulty, veryHardQuestions.length);
        Question[] selectedVeryHard = selectRandomQuestions(veryHardQuestions, actualNum);
        System.arraycopy(selectedVeryHard, 0, selectedQuestions, index, actualNum);
        index += actualNum;


        // If the selected questions are less than the required number, select from remaining questions.
        if (index < num) {
            Question[] remainingQuestions = new Question[num - index];
            int remainingIndex = 0;

            for (Question question : questions) {
                if (question == null) continue;
                int count = 0;

                for (int j = 0; j < index; j++) {
                    if (selectedQuestions[j] != question) {
                        count++;
                    }
                }


                if (count == index) {
                    remainingQuestions[remainingIndex++] = question;
                    if (remainingIndex == remainingQuestions.length) {
                        break;
                    }
                }
            }
            Question[] totalQuestions = new Question[num];
            System.arraycopy(selectedQuestions, 0, totalQuestions, 0, index);
            System.arraycopy(remainingQuestions, 0, totalQuestions, index, remainingQuestions.length);
            return totalQuestions;
        }
        return selectedQuestions;
    }

    /**
     * Classifies questions based on their difficulty level.
     * This method takes an array of questions and filters them by the specified difficulty level,
     * returning an ArrayList of questions that match the criteria.
     */
        private static Question[] classify(Question[] questions, Difficulty difficulty) {
        int numOfquestion =0;
        for (Question question : questions) {
            if (question!=null&&question.getDifficulty()==difficulty) {
                numOfquestion++;
            }
        }
        Question[] Questions_difficulty = new Question[numOfquestion];
        int count=0;
        for (int i = 0; i < questions.length; i++) {
            if (questions[i].getDifficulty() == difficulty) {
                Questions_difficulty[count] = questions[i];
                count++;
            }
        }
        return Questions_difficulty;
    }


    /**
     * Selects a random subset of questions from the provided list.
     * This method shuffles the list of questions and selects the first 'n' questions.
     * The resulting ArrayList contains the selected questions.
     */
    private static Question[] selectRandomQuestions(Question[] questions, int n) {
        if(questions.length>1){
            for (int i = 0; i < questions.length; i++) {
                int j = (int) (Math.random() * questions.length);
                Question tmp = questions[j];
                questions[j] = questions[i];
                questions[i] = tmp;
            }
            Question[] selectedQuestions = new Question[n];

            for (int i = 0; i < n; i++) {
                selectedQuestions[i] = questions[i];
            }
            return selectedQuestions;
        }
        return questions;
    }


    /**
     * Randomly change the order of the options for each question in the array.
     * This method takes an array of questions and rearranges the options for each question
     * to ensure that the order is random.
     */
    public static Option[] changeOptionsOrder(Option[] options) {
        for (int i = 0; i < options.length; i++) {
            int j = (int) (Math.random() * options.length);
            Option tmp = options[j];
            options[j] = options[i];
            options[i] = tmp;
        }
        return options;
    }


    /**
     * Calculates the score based on the user's answers and the correct answers.
     * This method compares the user's answers with the correct answers for each question
     * and computes the total score accordingly.
     */
    public static int calculateScore(List<Integer> correctAnswers, List<Integer> userAnswers) {
        int score = 0;
        double pointsPerQuestion = 100.0/num;
        int numOfcorrectAnswers=0;
        for (int i = 0; i < correctAnswers.size(); i++) {
            if(correctAnswers.get(i)==userAnswers.get(i)){
                score += pointsPerQuestion;
                numOfcorrectAnswers++;
            }
        }
        if(numOfcorrectAnswers==correctAnswers.size()){
            score =100;
        }
        return (int) Math.ceil(score);
    }

    /**
     * Writes the user's score to a CSV file.
     * This method takes the filename, user's ID, and score as input and appends the score to the specified CSV file.
     * If an I/O error occurs while writing to the file, an exception is thrown.
     */
    public static void writeScoreToCsv(String filename, String userId, int score) throws IOException {

        List<String[]> records = new ArrayList<>();

        // Read existing CSV file content
        BufferedReader br = new BufferedReader(new FileReader(filename));
        String line;
        while ((line = br.readLine()) != null) {
            String[] fields = line.split(",");
            if (fields[0].equals(userId)) {
                if (fields.length == 1) {
                    // User exists but has no score record
                    records.add(new String[] { userId, String.valueOf(score),String.valueOf(score) });
                }
                else {
                    int highestScore = Integer.parseInt(fields[1]);
                    // Update the highest score
                    if (score > highestScore) {
                        fields[1] = ""+score;
                    }
                    // Add a new score
                    String[] updatedFields = new String[fields.length + 1];
                    System.arraycopy(fields, 0, updatedFields, 0, fields.length);
                    updatedFields[fields.length] = ""+score;
                    records.add(updatedFields);
                }
            }
            else {
                records.add(fields);
            }
        }
        br.close();
        // Write back to the CSV file using BufferedWriter
        BufferedWriter writer = new BufferedWriter(new FileWriter(filename));
        for (String[] record : records) {
            writer.write(String.join(",", record));
            writer.newLine();
        }
        writer.close();
    }

    /**
     * Conducts a quiz test with the given set of questions and records the user's answers.
     * This method utilizes an array of questions for the quiz and a Scanner object to interact with the user,
     * capturing their responses. It handles I/O operations, which may result in exceptions.
     */
    public static void test(Question[] questions,Scanner scanner) throws IOException {
        Question[] testQuestions = selectQuestion(questions, num);
        List<Integer> userAnswer = new ArrayList<>();
        List<Integer> correctAnswer = new ArrayList<>();
        for (int i = 0; i < testQuestions.length; i++) {
            System.out.println("Question #" + (i + 1) + ": " + testQuestions[i].getQuestionStatement());
            Option[] options = testQuestions[i].getOptions();
            options = changeOptionsOrder(options);
            //Show each options
            for (int j = 0; j < options.length; j++) {
                System.out.println((j + 1) + ". " + options[j].getAnswer());
                if(options[j].isCorrectAnswer()){
                    correctAnswer.add(j+1);
                }
            }
            while (true) {
                try {
                    System.out.print("Enter your answer : ");
                    int answers = Integer.parseInt(scanner.nextLine());

                    boolean correctInput = true;
                    if (answers < 1 || answers > options.length) {
                        System.out.println("Invalid choice: " + answers + ". Please select number between 1 and " + options.length + ".");
                        correctInput = false;
                    }

                    if (correctInput) {
                        userAnswer.add(answers);
                        break;
                    }
                } catch (NumberFormatException e) {
                    System.out.println("Invalid input format. Please enter numbers only.");
                }
            }
        }
        int score = calculateScore(correctAnswer, userAnswer);
        System.out.println("Your score: " + score);
        writeScoreToCsv(csvFile, loggedInUser.getUserId(), score);
    }



    /**
     * Initiates the quiz-taking process by reading questions, selecting a topic, choosing the number of questions,
     * and conducting the test.
     * This method starts the quiz by loading questions, prompting the user to select a topic,
     * choosing how many questions to include, and then running the quiz itself.
     * It handles user input through a Scanner object and may encounter I/O errors during the process.
     */
    public static void takingQuiz(Scanner scanner) throws IOException {
        // Prompt the user to select a topic
        chooseTopic(scanner);
        // Prompt the user to choose the number of questions for the quiz
        chooseQuestionNum(scanner);
        // Conduct the test with the selected questions and record the user's answers
        test(questions,scanner);
        // Inform the user that the quiz is over and return to the show
        System.out.println("Quiz is over!");
        System.out.println("Go back to the menu...");
    }

}
