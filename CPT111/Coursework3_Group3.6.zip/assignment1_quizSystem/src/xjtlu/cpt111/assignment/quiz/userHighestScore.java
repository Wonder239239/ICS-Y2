package xjtlu.cpt111.assignment.quiz;

public class userHighestScore {
    private String userName;
    private int highestScore;
    public userHighestScore() {
        this.highestScore = 0;
        this.userName = "";
    }
    public userHighestScore(String userName, int highestScore) {
        this.userName = userName;
        this.highestScore = highestScore;
    }
    public String getUserName() {
        return userName;
    }

    public int getHighestScore() {
        return highestScore;
    }

    @Override
    public String toString() {
        return "userName: " + userName + ", highestScore: " + highestScore;
    }
}
