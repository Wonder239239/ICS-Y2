package xjtlu.cpt111.assignment.quiz;

public class SharedUser {
    private String userId;
    private String userName;
    private String password;

    public SharedUser(String userId, String userName, String password) {
        this.userId = userId;
        this.userName = userName;
        this.password = password;
    }
    public SharedUser(){
        this.userId = "";
        this.userName = "";
        this.password = "";
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean matchPassword(String userId, String password) {
        return this.userId.equals(userId) && this.password.equals(password);
    }
}
