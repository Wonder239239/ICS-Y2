package xjtlu.cpt111.assignment.quiz;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;
import static xjtlu.cpt111.assignment.quiz.Menu.loggedInUser;

public class Login extends SharedUser{
    private static final String CSV_FILE = "resources/users.csv";
    private static final String csScore = "resources/scores-cs.csv";
    private static final String eeScore = "resources/scores-ee.csv";
    private static final String englishScore = "resources/scores-english.csv";
    private static final String mathematicsScore = "resources/scores-mathematics.csv";
    private static ArrayList<SharedUser> users = new ArrayList<>();

    //Load the existing information in user.csv file, convert the information in user.csv into a SharedUser object and store it in the users list.
    public static void load() {
        users.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] values = line.split(",");
                if (values.length == 3) {
                    SharedUser userInfo = new SharedUser(values[0], values[1], values[2]);
                    users.add(userInfo);
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading the CSV file: " + e.getMessage());
        }
    }

    //Check that the id and password you passed whether matches the SharedUser in the users list.
    public static boolean check(String userId, String password) {
        for (SharedUser userInfo : users) {
            if (userInfo.matchPassword(userId, password)) {
                return true;
            }
        }
        return false;
    }

    //The login method
    public static void login(Scanner scanner) {
        while (true) {
            System.out.print("Enter user ID: ");
            String userId = scanner.nextLine();
            System.out.print("Enter password: ");
            String password = scanner.nextLine();
            //An error message is given if the input id is empty
            if (userId == null || userId.isEmpty() || userId.contains(" ")) {
                System.out.println("User ID cannot be empty or contain spaces. Please try again.");
                continue;
            }
            //An error message is given if the password entered is empty
            if (password == null || password.isEmpty() || password.contains(" ")) {
                System.out.println("Password cannot be empty or contain spaces. Please try again.");
                continue;
            }
            //Call the check method to see if there are any registered matching users
            if (check(userId, password)) {
                SharedUser loginUserInformation = null;
                for (SharedUser userInformation : users) {
                    if (userInformation.matchPassword(userId, password)) {
                        //Pass the matched user found to a SharedUser object named loginUserInformation
                        loginUserInformation = userInformation;
                        break;
                    }
                }
                loggedInUser = new SharedUser(
                        loginUserInformation.getUserId(),
                        loginUserInformation.getUserName(),
                        loginUserInformation.getPassword()
                );
                System.out.println("Login successful!");
                System.out.println("Hello, " + loginUserInformation.getUserName() + "!");
                return; // Login successfully and exit the method.
            }
            //If the id or password entered does not exist or is incorrect, an error message will be displayed
            else {
                System.out.println("Invalid user ID or password. Please try again.");
                //Choose to log in or register again
                while (true) {
                    System.out.print("Do you want to try again or register? (Enter '1' to try again, '2' to register): ");
                    int choice;
                    try {
                        choice = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) { //catch NumberFormatException
                        System.out.println("Invalid input. Please enter '1' or '2'.");
                        continue;
                    }

                    switch (choice) {
                        case 1:
                            // Back to login loop.
                            break;
                        case 2:
                            register(scanner);
                            return; // Exit method when registration is complete
                        default:
                            System.out.println("Invalid choice. Please enter '1' or '2'.");
                            continue;
                    }
                    break;
                }
            }
        }
    }

    //The register method
    public static void register(Scanner scanner) {
        while (true) {
            System.out.print("Enter new user ID: ");
            String userId = scanner.nextLine();
            //An error message is given if the input id is empty
            if (userId == null || userId.isEmpty() || userId.contains(" ")) {
                System.out.println("User ID cannot be empty or contain spaces. Please try again.");
                continue;
            }
            //Check if it's already registered
            boolean isExist = false;
            //Iterate over the users list to see if any ids have been registered
            for (SharedUser userInformation : users) {
                if (userInformation.getUserId().equals(userId)) {
                    System.out.println("User ID already exists. Please choose a different user ID or return to login.");
                    isExist = true;
                    break;
                }
            }

            if (isExist) {
                // Mention the user to login or register again
                while (true) {
                    System.out.print("Do you want to try registering again or return to login? (Enter '1' to register, '2' to login): ");
                    int choice;
                    try {
                        choice = Integer.parseInt(scanner.nextLine());
                    } catch (NumberFormatException e) { // catch NumberFormatException
                        System.out.println("Invalid input. Please enter '1' or '2'.");
                        continue;
                    }

                    switch (choice) {
                        case 1:
                            // New entry into the registration loop
                            break;
                        case 2:
                            login(scanner);
                            return; // Back to login
                        default:
                            System.out.println("Invalid choice. Please enter '1' or '2'.");
                            continue;
                    }
                    break;
                }
            } else {
                System.out.print("Enter your name: ");
                String userName = scanner.nextLine();

                System.out.print("Enter your new password: ");
                String password = scanner.nextLine();

                if (password == null || password.isEmpty() || password.contains(" ")) {
                    System.out.println("Password cannot be empty or contain spaces. Please try again.");
                    continue;
                }
                //Instantiate the new SharedUser object and put the registration information in, then add it to the users list
                SharedUser newUser = new SharedUser(userId, userName, password);
                users.add(newUser);
                //Writes user information to each files
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(CSV_FILE, true))) {
                    writer.write(newUser.getUserId() + "," + newUser.getUserName() + "," + newUser.getPassword());
                    writer.newLine();
                } catch (IOException e) {
                    System.err.println("Error writing to the CSV file: " + e.getMessage());
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(csScore, true))) {
                    writer.write(newUser.getUserId());
                    writer.newLine();
                } catch (IOException e) {
                    System.err.println("Error writing to the CSV file: " + e.getMessage());
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(eeScore, true))) {
                    writer.write(newUser.getUserId());
                    writer.newLine();
                } catch (IOException e) {
                    System.err.println("Error writing to the CSV file: " + e.getMessage());
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(englishScore, true))) {
                    writer.write(newUser.getUserId());
                    writer.newLine();
                } catch (IOException e) {
                    System.err.println("Error writing to the CSV file: " + e.getMessage());
                }

                try (BufferedWriter writer = new BufferedWriter(new FileWriter(mathematicsScore, true))) {
                    writer.write(newUser.getUserId());
                    writer.newLine();
                } catch (IOException e) {
                    System.err.println("Error writing to the CSV file: " + e.getMessage());
                }

                loggedInUser = newUser;

                System.out.println("New user created successfully!");
                return; // exit the method after register successfully
            }
        }
    }
    //Overall method of login and register
    public static void userLogin(Scanner scanner) {
        load();
        int choice=-1;
        while (true) {
            System.out.println("Hello, do you want to login or register?");
            System.out.println("Enter '1' to login or '2' to register");
            System.out.print("Please enter your choice：");
            try {
                choice = Integer.parseInt(scanner.nextLine());
                if (choice != 1 && choice != 2) {
                    System.out.println("Invalid input. Please enter '1' or '2'.");
                    continue;
                }
            } catch (NumberFormatException e) { // catch NumberFormatException
                System.out.println("Invalid input. Please enter '1' or '2'.");
                continue;
            }
            switch (choice) {
                case 1:
                    login(scanner);
                    break;
                case 2:
                    register(scanner);
                    break;
            }
            break;

        }
    }
}