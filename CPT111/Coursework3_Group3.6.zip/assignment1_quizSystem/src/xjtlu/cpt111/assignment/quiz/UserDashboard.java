package xjtlu.cpt111.assignment.quiz;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class UserDashboard {
    //Store the path of the CSV file
    private static String CSV_FILE ;
    // First is logic The function is to display the user's highest score
    // The first step is to determine whether the user has successfully logged in to the class variable in sharUser
    // The requirements of the assignment are to display the highest score for each subject, allowing the user to select which subject they want to view
    // Read part of the corresponding file




    //Define the path
    private static final String cs = "resources/scores-cs.csv";
    private static final String ee = "resources/scores-ee.csv";
    private static final String english = "resources/scores-english.csv";
    private static final String mathematics = "resources/scores-mathematics.csv";

    /**
     * Choose the subjects
     */
    public static void choose(Scanner scanner) {
        System.out.println("Choose a topic");
        int choice;// Enter the selection
        // A while loop until the correct information is entered
        while (true) {
            // Print optional subjects
            System.out.println("1. Computer Science (cs) ");
            System.out.println("2. Electrical Engineering (ee) ");
            System.out.println("3. English ");
            System.out.println("4. Mathematics ");
            System.out.println("Please enter a number to choose the topic ");
            System.out.print("Your choice: ");
            String input = scanner.nextLine();// Read the input
            try {
                choice = Integer.parseInt(input);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input, please enter a number!");
                continue;
            }
            // Set the path according to the selection
            switch (choice) {
                case 1:
                    CSV_FILE = cs;
                    break;
                case 2:
                    CSV_FILE = ee;
                    break;
                case 3:
                    CSV_FILE = english;
                    break;
                case 4:
                    CSV_FILE = mathematics;
                    break;
                default:
                    System.out.println("Please choose the number between 1 to 4, please choose again!");
                    continue;
            }
            break;
        }
    }



    /**
     *  Print recent 3 scores of the user.
     */
    public static void printScores(Scanner scanner) {
        SharedUser user = Menu.loggedInUser;// Read the user
        String userId = user.getUserId();// Read the ID
        choose(scanner);// Choose the subject
        List<Integer> recentScores = getRecentScores(userId, 3);// Get the last 3 results
        if (recentScores.isEmpty()||recentScores.size()<3) {// Less than 3 times
            System.out.println("Dear "+userId+", you haven't taken at least 3 quizzes, please take more quiz to see your recent 3 scores!");
        } else {
            System.out.println("Recent 3 scores for user " + userId + ": ");//输出成绩
            for(Integer score : recentScores) {
                System.out.println("\t" + score + "\t");
            }
        }
    }


    // Method of obtaining user scores based on user ID and the number of recent N scores

    /**
     * This method is used to get the score of the most recent recentN for the specified user
     * @param userId
     * @param recentN
     * @return Method returns a list of the user's most recent n test scores
     */
    public static List<Integer> getRecentScores(String userId, int recentN) {
        List<Integer> scores = new ArrayList<>();// Store the list of grades

        // Read the CSV file
        try (BufferedReader reader = new BufferedReader(new FileReader(CSV_FILE))) {
            String line;
            while ((line = reader.readLine()) != null) {// Read the score line by line
                String[] values = line.split(",");// Separate with commas
                if (values.length > 2 && values[0].equals(userId)) {// Read the score from the third column (index 2, because the index starts at 0)
                    for (int i = 2; i < values.length; i++) {
                        try {
                            scores.add(Integer.parseInt(values[i]));// Add the result to the list
                        } catch (NumberFormatException e) {
                            System.err.println("Invalid score value: " + values[i]);// If the format is incorrect, an error message will be printed
                        }
                    }
                    break;// Exit the loop after finding the score
                }
            }
        } catch (IOException e) {
            System.err.println("Error reading the CSV file: " + e.getMessage());// An error message will be printed if the file fails to be read
        }
        if (scores.isEmpty()) {// An empty list will be returned if there is no score
            return scores;
        }
        // Calculate the starting index of the last N grades
        int fromIndex = Math.max(0, scores.size() - recentN);
        // Returns to the starting index of the last N scores
        return scores.subList(fromIndex, scores.size());
    }
}



